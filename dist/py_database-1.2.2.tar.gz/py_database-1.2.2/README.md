# py-database
py-database is an esoteric library which helps you use python files as databases.